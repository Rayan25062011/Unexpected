# Security Policy

## Versions with regular updates

| Version | Regular updates    |
| ------- | ------------------ |
| 1.1     | :white_check_mark: |
| 1.2     | :white_check_mark: |

## Reporting a Vulnerability

If you find any vulnerabilities please tell us in the issue section
